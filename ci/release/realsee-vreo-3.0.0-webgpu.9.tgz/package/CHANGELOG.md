# CHANGELOG

## 2.6.4

- feat: 讲解支持应用侧 PlaybackManager，一段讲解共享播放任务，保留内部音轨混音。
- fix: 暂停、抢占和销毁同步停止成员媒体，取消延迟加载与关键帧，避免旧任务复播。
- chore: dnalogel peer/dev 依赖统一为正式版 3.81.10。

# 2.0.0
- fix: 重新实现了运镜功能，修复了运镜掉帧的问题
- break-change：修复了模型态切换全景态时的目标点位为0时，有可能不会真正移动到目标位置的问题。该问题的修复会导致之前的一些基于此bug制作的导览出现问题，需要重新制作。

# 1.0.0-alpha.21
- fix: 多段BgMusic播放问题

# 1.0.0-alpha.19
- fix: 多段BgMusic可以重复播放

# 1.0.0-alpha.18
- fix: 修复无音频版本中途播放会从头开始的问题

# 1.0.0-alpha.1
- feat: css样式适配: 手机横竖屏, pad, pc
- feat: 新增两种波浪风格: 'wave' | 'solid'
- feat: 标签调用dna插件
- fix: 图片/视频 弹窗UI问题

# 0.2.0-alpha.25
- feat: rotate 不指定顺时针或者逆时针，则按照锐角交互。

# 0.2.0-alpha.24
- fix: 修复 CSS3DRender 与插件库样式冲突问题。
- fix: 修复示例 wrapper 定位问题。

# 0.2.0-alpha.23
- fix: 修复21版本针对非旋转运镜使用了旋转速度问题修复的代码丢失问题。

# 0.2.0-alpha.22
- fix: 修复运镜顺时针逆时针反向问题。

# 0.2.0-alpha.21
- fix: 修复非旋转运镜使用了旋转速度问题。

# 0.2.0-alpha.20
- fix: 修复 `paused` 事件抛出 `ended` 回调带来的重复抛出事件问题。

# 0.2.0-alpha.19
- feat: 新增 `getCurrentTime()` 方法，支持实时获取当前播放时间点；
- feat: 新增 `ended` 标识，当检测到 video 实例 `ended` 以后会在 `paused` 事件里抛出 `true` 回调。
