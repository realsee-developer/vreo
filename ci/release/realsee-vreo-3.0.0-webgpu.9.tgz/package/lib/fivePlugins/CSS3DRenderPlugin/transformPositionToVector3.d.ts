import { Vector3 } from 'three/webgpu';
declare const transformPositionToVector3: ({ x, y, z }: {
    x: number;
    y: number;
    z: number;
}) => Vector3;
export default transformPositionToVector3;
//# sourceMappingURL=transformPositionToVector3.d.ts.map