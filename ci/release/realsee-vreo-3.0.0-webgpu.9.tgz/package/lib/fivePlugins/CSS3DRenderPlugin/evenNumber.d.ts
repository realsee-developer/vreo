export default function evenNumber(num: number, config?: {
    smaller?: boolean;
}): number;
//# sourceMappingURL=evenNumber.d.ts.map