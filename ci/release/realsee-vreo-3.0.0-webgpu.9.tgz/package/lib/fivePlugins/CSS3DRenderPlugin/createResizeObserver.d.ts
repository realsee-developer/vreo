export default function createResizeObserver(callback: () => void, element?: HTMLElement): {
    observe(): void;
    unobserve(): void;
    disconnect(): void;
};
//# sourceMappingURL=createResizeObserver.d.ts.map