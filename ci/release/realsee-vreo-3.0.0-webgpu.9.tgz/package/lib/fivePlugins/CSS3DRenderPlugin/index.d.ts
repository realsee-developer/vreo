import { FivePlugin } from '@realsee/five-webgpu';
import { Vector3 } from 'three/webgpu';
import { CSS3DObject } from 'three/addons/renderers/CSS3DRenderer.js';
export interface Vector3Position {
    x: number;
    y: number;
    z: number;
}
export type CSS3DRenderPluginParameterType = undefined;
export interface CSS3DRenderPluginExportType {
    create3DDomContainer: (points: Vector3[] | Vector3Position[], config?: {
        ratio?: number;
        dpr?: number;
        autoRender?: boolean;
        container?: HTMLElement;
        [key: string]: any;
    } & ({
        mode?: 'front';
    } | {
        mode: 'behind';
        behindFiveContainer: HTMLElement;
    })) => {
        container: HTMLElement;
        dispose: () => void;
        css3DObject: CSS3DObject;
        render?: () => void;
    } | void;
    disposeAll: () => void;
}
/** Renders DOM overlays in a Five scene. One renderer is shared by each front/behind layer. */
export declare const CSS3DRenderPlugin: FivePlugin<CSS3DRenderPluginParameterType, CSS3DRenderPluginExportType>;
export default CSS3DRenderPlugin;
//# sourceMappingURL=index.d.ts.map