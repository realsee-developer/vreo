import { Vector3 } from 'three/webgpu';
export default function centerPoint(point1: Vector3, point2: Vector3): Vector3;
//# sourceMappingURL=centerPoint.d.ts.map