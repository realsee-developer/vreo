import type { FivePlugin } from '@realsee/five-webgpu';
import type { PlaybackManager } from '../../Player/playback-types';
export interface ModelTVVideoPluginData {
    enable?: boolean;
    video_src: string;
    video_poster_src: string;
    points: {
        x: number;
        y: number;
        z: number;
    }[][];
}
export interface ModelTVVideoPluginParameterType {
    videoElement?: HTMLVideoElement;
    mediaManager?: PlaybackManager;
}
export interface ModelTVVideoPluginExportType {
    enable: () => void;
    disable: () => void;
    dispose: () => void;
    load: (data: ModelTVVideoPluginData, videoElement?: HTMLVideoElement) => Promise<void>;
}
export declare const ModelTVVideoPlugin: FivePlugin<ModelTVVideoPluginParameterType, ModelTVVideoPluginExportType>;
//# sourceMappingURL=index.d.ts.map