export interface TimelineKeyframe {
    type: string;
    start: number;
    end: number;
    parsed?: boolean;
}
/** Deterministic keyframe selection. Runtime state never mutates timeline input. */
export declare class Timeline<Keyframe extends TimelineKeyframe = TimelineKeyframe> {
    private keyframes;
    private consumed;
    load(keyframes: readonly Keyframe[]): void;
    pendingAt(currentTime: number): Keyframe[];
    take(currentTime: number): Keyframe[];
    seek(currentTime: number): void;
    reset(type?: Keyframe['type']): void;
    clear(): void;
}
//# sourceMappingURL=index.d.ts.map