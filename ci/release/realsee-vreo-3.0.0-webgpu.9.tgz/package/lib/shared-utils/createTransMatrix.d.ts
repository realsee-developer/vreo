import * as THREE from 'three/webgpu';
export declare function createTransMatrix(arr1: number[]): (arr2: number[]) => THREE.Vector3Tuple;
//# sourceMappingURL=createTransMatrix.d.ts.map