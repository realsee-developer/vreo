export default function getFileExpandedName(filePath?: string | null): string;
//# sourceMappingURL=getFileExpandedName.d.ts.map