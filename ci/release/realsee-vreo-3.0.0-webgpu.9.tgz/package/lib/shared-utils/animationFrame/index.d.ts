declare const requestFrame: typeof requestAnimationFrame & ((callback: FrameRequestCallback) => number);
export default requestFrame;
export declare function nextFrame(fn: FrameRequestCallback, delay?: number): void;
export declare function requestAnimationFrameInterval(callback?: (time: number) => unknown, frame?: number): () => void;
export declare function getFrameTime(): Promise<number>;
//# sourceMappingURL=index.d.ts.map