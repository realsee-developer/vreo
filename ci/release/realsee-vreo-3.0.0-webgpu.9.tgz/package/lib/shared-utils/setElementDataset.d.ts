export default function setElementDataset(element: any, dataset: Record<string, string | number>): void;
//# sourceMappingURL=setElementDataset.d.ts.map