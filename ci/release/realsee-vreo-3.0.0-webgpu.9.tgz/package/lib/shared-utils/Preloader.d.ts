/**
 * 预载器
 */
export declare const Preloader: {
    blob: (url: string) => Promise<string>;
};
//# sourceMappingURL=Preloader.d.ts.map