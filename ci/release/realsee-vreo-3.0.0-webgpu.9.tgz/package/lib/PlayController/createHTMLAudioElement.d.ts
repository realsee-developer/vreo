export declare function createHTMLAudioElement(): HTMLAudioElement;
//# sourceMappingURL=createHTMLAudioElement.d.ts.map