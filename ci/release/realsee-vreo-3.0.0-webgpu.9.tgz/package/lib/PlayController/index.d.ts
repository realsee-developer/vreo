import { Subscribe } from '@realsee/five-webgpu';
import { VreoKeyframeEvent, VreoUnit } from '../typings/VreoUnit';
export interface PlayControllerConfig {
    audio?: HTMLAudioElement;
}
export declare class PlayController extends Subscribe<VreoKeyframeEvent> {
    vreoUnit?: VreoUnit;
    readonly config: PlayControllerConfig;
    private readonly timeline;
    private readonly ownsAudio;
    private readonly stopInterval;
    private playPromise?;
    private disposed;
    private readonly onPlaying;
    private readonly onPaused;
    private readonly onEnded;
    get paused(): boolean;
    get audioInstance(): HTMLAudioElement;
    get currentTime(): number;
    get currentKeyframes(): import("..").VreoKeyframe[];
    get duration(): number;
    constructor(config?: PlayControllerConfig);
    load(vreoUnit: VreoUnit): Promise<boolean>;
    play(): Promise<boolean>;
    pause(): Promise<void>;
    dispose(): void;
}
//# sourceMappingURL=index.d.ts.map