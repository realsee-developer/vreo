export declare function PopUp(): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=index.d.ts.map