export declare function ResizeObserver(): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=index.d.ts.map