import * as React from 'react';
import { VideoAgentMeshOptions } from './VideoAgentMesh';
export declare const VideoAgent: ((props: {
    onClick?: () => void;
    options?: VideoAgentMeshOptions;
}) => import("react/jsx-runtime").JSX.Element) & React.NamedExoticComponent<{
    onClick?: () => void;
    options?: VideoAgentMeshOptions;
}> & {
    readonly type: (props: {
        onClick?: () => void;
        options?: VideoAgentMeshOptions;
    }) => import("react/jsx-runtime").JSX.Element;
};
//# sourceMappingURL=index.d.ts.map