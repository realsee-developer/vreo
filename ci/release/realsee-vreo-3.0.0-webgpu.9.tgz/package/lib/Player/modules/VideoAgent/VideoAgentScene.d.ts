import { OrthographicCamera, Scene, WebGPURenderer } from 'three/webgpu';
import { VideoAgentMesh, VideoAgentMeshOptions } from './VideoAgentMesh';
export declare class VideoAgentScene {
    videoAgentMesh: VideoAgentMesh;
    scene: Scene;
    camera: OrthographicCamera;
    renderer: WebGPURenderer;
    private frame;
    private disposed;
    disposers: (() => void)[];
    constructor(container?: HTMLElement, options?: VideoAgentMeshOptions, forceWebGL?: boolean);
    private fail;
    run: () => void;
    dispose: () => void;
}
//# sourceMappingURL=VideoAgentScene.d.ts.map