export declare function InfoPanel(): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=index.d.ts.map