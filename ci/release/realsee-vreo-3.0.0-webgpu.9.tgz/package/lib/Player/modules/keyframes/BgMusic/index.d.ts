export declare function BgMusic(): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=index.d.ts.map