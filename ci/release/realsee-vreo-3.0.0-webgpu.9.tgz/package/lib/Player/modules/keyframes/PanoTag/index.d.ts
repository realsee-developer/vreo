export declare function PanoTag(): null;
//# sourceMappingURL=index.d.ts.map