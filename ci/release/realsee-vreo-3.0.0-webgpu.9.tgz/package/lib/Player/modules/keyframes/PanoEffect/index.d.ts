export declare function PanoEffect(): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=index.d.ts.map