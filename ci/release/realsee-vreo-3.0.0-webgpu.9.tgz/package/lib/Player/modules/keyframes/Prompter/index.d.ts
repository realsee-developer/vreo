export declare function Prompter(): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=index.d.ts.map