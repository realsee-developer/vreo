export declare function ModelVideo(): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=index.d.ts.map