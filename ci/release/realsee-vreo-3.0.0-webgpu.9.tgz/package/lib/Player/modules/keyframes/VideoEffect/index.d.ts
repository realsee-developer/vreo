export declare function VideoEffect(): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=index.d.ts.map