import * as THREE from 'three/webgpu';
import { Five } from '@realsee/five-webgpu';
export default function lineAnime(five: Five, startPoint: THREE.Vector3, endPoint: THREE.Vector3): import("../../../../shared-utils/animationFrame/BetterTween").BetterTween<{
    progress: number;
}>;
//# sourceMappingURL=lineAnime.d.ts.map