/**
 * 空间文本标签。
 */
export declare function PanoTextLabel(): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=index.d.ts.map