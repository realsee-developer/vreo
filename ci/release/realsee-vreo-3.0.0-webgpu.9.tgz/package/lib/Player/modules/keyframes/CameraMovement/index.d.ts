export declare function CameraMovement(): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=index.d.ts.map