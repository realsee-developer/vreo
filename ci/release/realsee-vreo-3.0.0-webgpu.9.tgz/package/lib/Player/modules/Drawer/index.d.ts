export declare function Drawer(): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=index.d.ts.map