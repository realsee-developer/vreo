import { Vector3 } from 'three/webgpu';
export declare function useController(): import("./Controller").Controller;
export declare function useFiveInstance(): import("@realsee/five-webgpu").Five;
export declare function useFiveProject2d(): (vector: Vector3) => import("three").Vector2 | null;
//# sourceMappingURL=hooks.d.ts.map