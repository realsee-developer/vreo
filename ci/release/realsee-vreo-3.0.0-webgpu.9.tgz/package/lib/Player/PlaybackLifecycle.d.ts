import type { MediaOperations, PlaybackManager, PlaybackSession } from './playback-types';
export interface PlaybackRun {
    readonly session?: PlaybackSession;
    readonly mediaManager?: PlaybackManager;
    valid(): boolean;
    bind(element: HTMLMediaElement): MediaOperations;
}
/** Local timeline lifetime only. Playback permission is owned by the injected manager. */
export declare class PlaybackLifecycle {
    private onStop;
    private controller?;
    private run?;
    private generation;
    private disposed;
    private members;
    constructor(manager: PlaybackManager | undefined, onStop: () => void);
    get active(): boolean;
    capture(): PlaybackRun | undefined;
    begin(userAction: boolean): boolean;
    add(stop: () => void): () => void;
    private stop;
    cancel(): void;
    finish(): void;
    dispose(): void;
}
//# sourceMappingURL=PlaybackLifecycle.d.ts.map